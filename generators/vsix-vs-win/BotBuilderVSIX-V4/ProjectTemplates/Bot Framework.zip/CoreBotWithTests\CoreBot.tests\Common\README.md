﻿# Note
This folder contains a set of helper classes and extensions used in the tests.
